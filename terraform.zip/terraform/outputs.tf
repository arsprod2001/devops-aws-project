# outputs.tf — Valeurs affichées après terraform apply
# Ces valeurs nous servent pour Ansible et kubectl

output "master_public_ip" {
  description = "IP publique du noeud master Kubernetes"
  value       = aws_eip.master.public_ip
}

output "master_private_ip" {
  description = "IP privée du noeud master"
  value       = aws_instance.k8s_master.private_ip
}

output "worker_public_ip" {
  description = "IP publique du noeud worker"
  value       = aws_instance.k8s_worker.public_ip
}

output "worker_private_ip" {
  description = "IP privée du noeud worker"
  value       = aws_instance.k8s_worker.private_ip
}

output "vpc_id" {
  description = "ID du VPC créé"
  value       = aws_vpc.main.id
}

output "ssh_master_command" {
  description = "Commande SSH pour se connecter au master"
  value       = "ssh -i ~/.ssh/devops-aws-key ubuntu@${aws_eip.master.public_ip}"
}

output "ssh_worker_command" {
  description = "Commande SSH pour se connecter au worker"
  value       = "ssh -i ~/.ssh/devops-aws-key ubuntu@${aws_instance.k8s_worker.public_ip}"
}

output "application_url" {
  description = "URL de l'application après déploiement"
  value       = "http://${aws_eip.master.public_ip}"
}