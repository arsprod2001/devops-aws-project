# main.tf — Point d'entrée de Terraform
# Définit le provider AWS et crée les instances EC2

# ─────────────────────────────────────────────────────────────
# CONFIGURATION TERRAFORM
# ─────────────────────────────────────────────────────────────
terraform {
  required_version = ">= 1.0"   # Version minimum de Terraform requise

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"         # Provider AWS version 5.x
    }
  }

  # Optionnel : Stocker l'état Terraform dans S3 pour le travail en équipe
  # backend "s3" {
  #   bucket = "mon-terraform-state"
  #   key    = "devops-project/terraform.tfstate"
  #   region = "ca-central-1"
  # }
}

# ─────────────────────────────────────────────────────────────
# PROVIDER AWS
# Configure Terraform pour utiliser AWS
# ─────────────────────────────────────────────────────────────
provider "aws" {
  region = var.aws_region
  # Les credentials sont lus depuis ~/.aws/credentials
  # (configuré avec aws configure)
}

# ─────────────────────────────────────────────────────────────
# EC2 — NŒUD MASTER KUBERNETES
# Gère le cluster K8s (Control Plane)
# ─────────────────────────────────────────────────────────────
resource "aws_instance" "k8s_master" {
  ami                    = var.ami_id              # Image Ubuntu 22.04
  instance_type          = var.instance_type       # t2.micro (Free Tier)
  key_name               = var.key_pair_name       # Clé SSH importée
  subnet_id              = aws_subnet.public.id    # Dans le sous-réseau public
  vpc_security_group_ids = [aws_security_group.k8s_master.id]

  # Configuration du disque principal
  root_block_device {
    volume_type           = "gp2"      # SSD General Purpose
    volume_size           = 20         # 20 Go (gratuit jusqu'à 30 Go Free Tier)
    delete_on_termination = true       # Supprimer le disque quand l'instance est détruite
  }

  # Script exécuté au premier démarrage de l'instance
  # Installe les outils de base
  user_data = <<-EOF
    #!/bin/bash
    # Mise à jour du système
    apt-get update -y
    apt-get upgrade -y

    # Installation des outils essentiels
    apt-get install -y curl wget git vim htop unzip

    # Désactiver le swap (requis pour Kubernetes)
    swapoff -a
    sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab

    # Charger les modules kernel nécessaires pour K8s
    modprobe overlay
    modprobe br_netfilter

    # Configuration réseau pour K8s
    cat <<EOT > /etc/sysctl.d/k8s.conf
    net.bridge.bridge-nf-call-iptables  = 1
    net.bridge.bridge-nf-call-ip6tables = 1
    net.ipv4.ip_forward                 = 1
    EOT
    sysctl --system

    echo "Préparation du serveur terminée !"
  EOF

  tags = {
    Name        = "${var.project_name}-k8s-master"
    Role        = "master"
    Environment = var.environment
  }
}

# ─────────────────────────────────────────────────────────────
# EC2 — NŒUD WORKER KUBERNETES
# Exécute les containers/pods de l'application
# ─────────────────────────────────────────────────────────────
resource "aws_instance" "k8s_worker" {
  ami                    = var.ami_id
  instance_type          = var.instance_type
  key_name               = var.key_pair_name
  subnet_id              = aws_subnet.public.id
  vpc_security_group_ids = [aws_security_group.k8s_worker.id]

  root_block_device {
    volume_type           = "gp2"
    volume_size           = 20
    delete_on_termination = true
  }

  user_data = <<-EOF
    #!/bin/bash
    apt-get update -y
    apt-get install -y curl wget git vim htop

    swapoff -a
    sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab

    modprobe overlay
    modprobe br_netfilter

    cat <<EOT > /etc/sysctl.d/k8s.conf
    net.bridge.bridge-nf-call-iptables  = 1
    net.bridge.bridge-nf-call-ip6tables = 1
    net.ipv4.ip_forward                 = 1
    EOT
    sysctl --system
  EOF

  tags = {
    Name        = "${var.project_name}-k8s-worker"
    Role        = "worker"
    Environment = var.environment
  }
}

# ─────────────────────────────────────────────────────────────
# ELASTIC IP — IP PUBLIQUE FIXE POUR LE MASTER
# Sans Elastic IP, l'IP change à chaque redémarrage
# ─────────────────────────────────────────────────────────────
resource "aws_eip" "master" {
  instance = aws_instance.k8s_master.id
  domain   = "vpc"

  tags = {
    Name = "${var.project_name}-master-eip"
  }
}