# vpc.tf — Création du réseau virtuel privé sur AWS
# Le VPC isole nos ressources du reste d'internet

# ─────────────────────────────────────────────────────────────
# VPC PRINCIPAL
# ─────────────────────────────────────────────────────────────
resource "aws_vpc" "main" {
  cidr_block           = var.vpc_cidr
  enable_dns_hostnames = true   # Permet la résolution DNS (important pour EC2)
  enable_dns_support   = true

  tags = {
    Name        = "${var.project_name}-vpc"
    Environment = var.environment
    Project     = var.project_name
  }
}

# ─────────────────────────────────────────────────────────────
# SOUS-RÉSEAU PUBLIC
# Les instances EC2 ici ont accès à internet
# ─────────────────────────────────────────────────────────────
resource "aws_subnet" "public" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = var.public_subnet_cidr
  availability_zone       = "${var.aws_region}a"  # Zone de disponibilité
  map_public_ip_on_launch = true   # EC2 reçoit automatiquement une IP publique

  tags = {
    Name = "${var.project_name}-public-subnet"
    Type = "Public"
  }
}

# ─────────────────────────────────────────────────────────────
# SOUS-RÉSEAU PRIVÉ
# Pour des ressources sans accès direct à internet (DB, etc.)
# ─────────────────────────────────────────────────────────────
resource "aws_subnet" "private" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = var.private_subnet_cidr
  availability_zone = "${var.aws_region}b"

  tags = {
    Name = "${var.project_name}-private-subnet"
    Type = "Private"
  }
}

# ─────────────────────────────────────────────────────────────
# INTERNET GATEWAY
# Permet aux instances du sous-réseau public de communiquer avec internet
# ─────────────────────────────────────────────────────────────
resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id

  tags = {
    Name = "${var.project_name}-igw"
  }
}

# ─────────────────────────────────────────────────────────────
# TABLE DE ROUTAGE
# Indique comment router le trafic : 0.0.0.0/0 → Internet Gateway
# ─────────────────────────────────────────────────────────────
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block = "0.0.0.0/0"                    # Tout le trafic...
    gateway_id = aws_internet_gateway.main.id    # ...passe par l'IGW
  }

  tags = {
    Name = "${var.project_name}-public-rt"
  }
}

# Associer la table de routage au sous-réseau public
resource "aws_route_table_association" "public" {
  subnet_id      = aws_subnet.public.id
  route_table_id = aws_route_table.public.id
}