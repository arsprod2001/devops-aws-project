# security_groups.tf — Règles de pare-feu AWS
# Un Security Group = un firewall virtuel pour les instances EC2

# ─────────────────────────────────────────────────────────────
# SECURITY GROUP — Nœud Master Kubernetes
# ─────────────────────────────────────────────────────────────
resource "aws_security_group" "k8s_master" {
  name        = "${var.project_name}-k8s-master-sg"
  description = "Security Group pour le noeud master Kubernetes"
  vpc_id      = aws_vpc.main.id

  # SSH — Pour se connecter et configurer avec Ansible
  ingress {
    description = "SSH depuis votre machine locale"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    # En production : remplacez par votre IP spécifique pour plus de sécurité
  }

  # API Kubernetes — kubectl communique sur ce port
  ingress {
    description = "Kubernetes API Server"
    from_port   = 6443
    to_port     = 6443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  # HTTP — Pour accéder à l'application web
  ingress {
    description = "HTTP"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  # HTTPS — Pour SSL/TLS (optionnel mais bonne pratique)
  ingress {
    description = "HTTPS"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  # NodePort Kubernetes (30000-32767) — Pour accéder aux services K8s
  ingress {
    description = "Kubernetes NodePorts"
    from_port   = 30000
    to_port     = 32767
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  # Communication interne entre nodes Kubernetes
  ingress {
    description = "Communication interne VPC"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"             # -1 = tous les protocoles
    cidr_blocks = [var.vpc_cidr]   # Seulement depuis le VPC
  }

  # Sortie : autoriser tout le trafic sortant
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "${var.project_name}-k8s-master-sg"
  }
}

# ─────────────────────────────────────────────────────────────
# SECURITY GROUP — Nœuds Workers Kubernetes
# ─────────────────────────────────────────────────────────────
resource "aws_security_group" "k8s_worker" {
  name        = "${var.project_name}-k8s-worker-sg"
  description = "Security Group pour les noeuds workers Kubernetes"
  vpc_id      = aws_vpc.main.id

  ingress {
    description = "SSH"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "Communication interne VPC"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = [var.vpc_cidr]
  }

  ingress {
    description = "NodePorts"
    from_port   = 30000
    to_port     = 32767
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "${var.project_name}-k8s-worker-sg"
  }
}