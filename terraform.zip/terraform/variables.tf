# variables.tf — Toutes les valeurs configurables du projet
# Modifier ces variables pour adapter à votre environnement

variable "aws_region" {
  description = "Région AWS où déployer l'infrastructure"
  type        = string
  default     = "us-east-1"   # Canada (Toronto)
}

variable "project_name" {
  description = "Nom du projet — utilisé pour nommer toutes les ressources"
  type        = string
  default     = "devops-student"
}

variable "environment" {
  description = "Environnement de déploiement"
  type        = string
  default     = "dev"
}

variable "vpc_cidr" {
  description = "Plage d'adresses IP du VPC"
  type        = string
  default     = "10.0.0.0/16"
  # 10.0.0.0/16 = 65,534 adresses IP disponibles
}

variable "public_subnet_cidr" {
  description = "Plage d'adresses du sous-réseau public"
  type        = string
  default     = "10.0.1.0/24"
  # /24 = 254 adresses disponibles
}

variable "private_subnet_cidr" {
  description = "Plage d'adresses du sous-réseau privé"
  type        = string
  default     = "10.0.2.0/24"
}

variable "instance_type" {
  description = "Type d'instance EC2 (t2.micro = Free Tier)"
  type        = string
  default     = "t2.micro"
  # t2.micro : 1 vCPU, 1 Go RAM — GRATUIT 750h/mois
}

variable "key_pair_name" {
  description = "Nom de la paire de clés SSH importée dans AWS"
  type        = string
  default     = "devops-aws-key"
}

variable "ami_id" {
  description = "ID de l'AMI Ubuntu 22.04 pour ca-central-1"
  type        = string
  default     = "ami-0b0ea68c435eb488d"
  # Ubuntu 22.04 LTS — us-east-1
  # Vérifier l'AMI la plus récente sur : https://cloud-images.ubuntu.com/locator/ec2/
}

variable "docker_username" {
  description = "Username Docker Hub pour les images"
  type        = string
  default     = "arsprod01"
}